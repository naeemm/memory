package fr.internet.memory.ean;
/*
 * Abstract interface for
 * every new service 
 */

public interface WebAgent {
    public Result Search();
}
