/**
 * 
 * @version 1.1
 * 
 * {@docRoot Multithreaded web scraper for food products}
 * 
 * @since 01/01/2017 
 * 
 * @author M. Naeem
 * 
 * @email Muhammad.Naeem@univ-lyon2.fr
 * 
 */
package fr.internet.memory.ean;